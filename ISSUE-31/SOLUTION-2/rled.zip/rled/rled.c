/**
 * Run Length Encoder/Decoder rled
 *
 * Olimex Weekend Programming Challenge
 * 
 * Author: Michael Shimniok (bot-thoughts.com)
 * Date:   11/1/2013
 */
#include <stdio.h>
#include <unistd.h>

/** function prototypes */
int encode(char *filename);
int decode(char *filename);
void usage();

/** return codes */
#define USAGE  1
#define DELIM  2
#define FILEIO 3

/** flags */
#define DECODE 0x01
#define ENCODE 0x02


int main(int argc, char **argv)
{
	extern char *optarg;
	int flags = 0;
	int status = 0;
	char c;
	char *filename = 0;

	/** parse arguments */
	while ((c = getopt(argc, argv, "e:d:")) != -1) {
		switch (c) {
		case 'e':
			flags |= ENCODE;
			filename = optarg;
			break;
		case 'd':
			flags |= DECODE;
			filename = optarg;
			break;
		}
	}

	/** run encode or decode */
	if (flags == ENCODE) {
		status = encode(filename);
	} else if (flags == DECODE) {
		status = decode(filename);
	} else {
		usage();
		status = USAGE;
	}

	return status;
}

/**
 * Run length encode specified filename
 * If only one instance, print the character, e.g., a
 * If more than one, print the character twice followed by the number of that character, e.g., aa12
 * records separated by \1
 */
int encode(char *filename)
{
	FILE *fp;
	int status = 0;
	char last = 0;
	char this = 0;
	int	count = 0;

	if ((fp = fopen(filename, "r")) == NULL) {
		fprintf(stderr, "can't open file %s\n", filename);
		status = FILEIO;
	} else {
		while (1) {
			// last time through this == EOF != last
			this = fgetc(fp);
			// input file can't have \1 or things possible get hosed
			if (this == '\1') {
				fprintf(stderr, "file cannot contain ^A\n");
				status = DELIM;
				break;
			} else if (this == last) { // add to count during 'run'
				count++;
			} else {
				// done with run, dump out the last char and count
				// only if > 1 so we print a or aa12 or whatever
				if (count > 1) {
					fprintf(stdout, "%c%d\1", last, count);
				}
				// dump out this char
				fputc(this, stdout);
				// we've gotten a new char so count is 1
				count = 1;
				// reset last
				last = this;
			}
			// waiting to bail until the loop end forces flush of multiple final chars
			if (this == EOF) break;
		}

	}
	return status;
}

/**
 * If only one character (a) then print it once
 * If more than one (aa) then read the following number
 * \1 terminates the number
 */
int decode(char *filename)
{
	FILE *fp;
	int status = 0;
	char this = 0;
	char last = 0;
	int count = 0;

	if ((fp = fopen(filename, "r")) == NULL) {
		fprintf(stderr, "can't open file %s\n", filename);
		status = FILEIO;
	} else {
		while ((this = fgetc(fp)) != EOF) {
			if (this != last) {
				fputc(this, stdout);
			} else {
				if (fscanf(fp, "%i", &count) == 1) {
					while (--count) {
						fputc(this, stdout);
					}
					if (fgetc(fp) != '\1') { // expecting delimiter
						fprintf(stderr, "delimiter missing\n");
						status = DELIM;
						break;
					}
				} else {
					fprintf(stderr, "error reading file %s\n", filename);
				}
			}
			last = this;
		}
	}
	return status;
}

/**
 * Display helpful usage
 */
void usage()
{
	fputs("usage: rled [-e|-d] filename\n  -e encode\n  -d decode\n", stderr);
	return;
}
