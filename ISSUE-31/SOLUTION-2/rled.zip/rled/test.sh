#!/bin/sh

for i in *.txt
do
	echo "======== $i ========"
	Release/rled -e $i > ${i%%.*}.rle
	Release/rled -d ${i%%.*}.rle > ${i%%.*}.dec
	diff $i ${i%%.*}.dec
	echo ""
done
