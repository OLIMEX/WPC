#include <stdio.h>
#include <dirent.h>
#include <errno.h>
#include <time.h>

#include <SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_ttf.h>

#define APP_NAME "SSnake - SDL Snake clone"

typedef struct tConfig {
	char *name;
	char *value;
} tConfig;

typedef struct tTile {
	int x;
	int y;
	int w;
	int h;
} tTile;

typedef struct tTokenizer {
        char **tokens;
        int numTokens;
} tTokenizer;

tTokenizer NO_TOKENS;

tTokenizer tokenize(char *string, char *by);
void free_tokens(tTokenizer t);

tTile *_tiles;
int _num_tiles;

tConfig *_configs;
int _num_configs;

TTF_Font *font;

// Config functions
void InitConfigs(void);
int ConfigLoad(char *filename);
char *ConfigGetValue(char *name);
int ConfigGetValueAsInteger(char *name);
int ConfigGetValueAsBoolean(char *name);
void ConfigDump(void);

// Tile functions
int TileCheckForCollision(int x, int y, int w, int h);
void TileAdd(int x, int y, int w, int h);
void InitTiles(void);
void FreeTiles(void);
