#define DEBUG_CONFIG
#include "Snake.h"

#ifdef DEBUG_CONFIG
#define DPRINTF(fmt, ...) \
do { fprintf(stderr, "[snake/config ] " fmt , ## __VA_ARGS__); } while (0)
#else
#define DPRINTF(fmt, ...) \
do {} while(0)
#endif

void InitConfigs(void)
{
	_configs = NULL;
	_num_configs = 0;
}

int ConfigParseLine(char *line)
{
	int i;
	char *tmp = strdup(line);

	char *val = strstr(line, "=") + 1;
	while (*val == ' ') *val++;

	tmp[strlen(tmp) - strlen(val) - 2] = 0;
	if (_configs == NULL)
		_configs = (tConfig *)malloc( sizeof(tConfig) );
	else
		_configs = (tConfig *)realloc( _configs, (_num_configs + 1) * sizeof(tConfig) );

	if (_configs == NULL)
		return 1;

	for (i = strlen(tmp); i > 0; i--)
		if (tmp[i] != ' ')
			break;

	tmp[i - 1] = 0;
	_configs[_num_configs].name = strdup(tmp);
	_configs[_num_configs].value = strdup(val);

	DPRINTF("%s: Adding config named '%s' with value '%s'\n", __FUNCTION__,
		tmp, val);
	_num_configs++;
	return 0;
}

void ConfigDump(void)
{
	int i;

	for (i = 0; i < _num_configs; i++) {
		fprintf(stderr, "Config #%d:\n", i + 1);
		fprintf(stderr, "\tName: %s\n", _configs[i].name);
		fprintf(stderr, "\tValue: %s\n", _configs[i].value);
	}
}

char *ConfigGetValue(char *name)
{
	int i;

	for (i = 0; i < _num_configs; i++)
		if (strcmp(_configs[i].name, name) == 0)
			return _configs[i].value;

	return NULL;
}

int ConfigGetValueAsInteger(char *name)
{
	char *value;

	value = ConfigGetValue(name);
	if (value == NULL)
		return 0;

	return atoi(value);
}

int ConfigGetValueAsBoolean(char *name)
{
	int ret = -1;
	char *value;

	value = ConfigGetValue(name);
	if (value == NULL)
		return ret;

	if (strcmp(value, "true") == 0)
		ret = 1;
	else
	if (strcmp(value, "yes") == 0)
		ret = 1;
	else
	if (strcmp(value, "false") == 0)
		ret = 0;
	else
	if (strcmp(value, "no") == 0)
		ret = 0;

	return ret;
}

int ConfigLoad(char *filename)
{
	char line[1024] = { 0 };
	FILE *fp = fopen(filename, "r");
	if (fp == NULL)
		return 1;

	while (!feof(fp)) {
		memset(line, 0, sizeof(line));
		fgets(line, sizeof(line), fp);

		if (line[strlen(line) - 1] == '\n')
			line[strlen(line) - 1] = 0;

		if (strlen(line) > 0)
			ConfigParseLine(line);
	}

	fclose(fp);
	return 0;
}

