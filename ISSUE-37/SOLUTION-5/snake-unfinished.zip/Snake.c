#define DEBUG_MAIN
#include "Snake.h"

#ifdef DEBUG_MAIN
#define DPRINTF(fmt, ...) \
do { fprintf(stderr, "[snake/main   ] " fmt , ## __VA_ARGS__); } while (0)
#else
#define DPRINTF(fmt, ...) \
do {} while(0)
#endif

#define BPP 4
#define DEPTH 32

#define DIR_UP		0
#define DIR_DOWN	1
#define DIR_LEFT	2
#define DIR_RIGHT	3

int head_x = 0;
int head_y = 0;
int wait_input = 0;
int dir = DIR_RIGHT;
int _score = 0;

int loadFonts(void)
{
	// TODO: Add dynamic location
	font = TTF_OpenFont("font.ttf", 36);
	if (font == NULL) {
		DPRINTF("%s: Cannot open font file\n", __FUNCTION__);
		return 1;
	}

	return 0;
}

int fontRender(SDL_Surface *screen, char *message, int x, int y)
{
	SDL_Rect rect;
	SDL_Surface *text;
	SDL_Color text_color = {50, 50, 255};
	text = TTF_RenderText_Solid(font,
		message,
		text_color);

	if (text == NULL)
		return 1;

	if ((x == -1) && (y == -1)) {
		x = (screen->w - text->w) / 2;
		y = (screen->h - text->h) / 2;
	}

	rect.x = x;
	rect.y = y;

	SDL_BlitSurface(text, NULL, screen, &rect);
	SDL_Flip(screen);

	return 0;
}

void GameLost(SDL_Surface *screen)
{
	char tmp[1024] = { 0 };

	snprintf(tmp, sizeof(tmp), "Your score is %d", _score);
	fontRender(screen, tmp, -1, -1);
	wait_input = 1;
}

void PutApple(SDL_Surface *screen)
{
	SDL_Rect rect;

	srand(time(NULL) * 2);
	rect.h = ConfigGetValueAsInteger("snake.size");
	rect.w = rect.h;
	rect.y = (rand() % screen->h);
	rect.x = (rand() % screen->w);
	while (TileCheckForCollision(rect.x, rect.y, rect.w, rect.h) == 1) {
		rect.y = (rand() % screen->h);
		rect.x = (rand() % screen->w);
		while ((rect.x % ConfigGetValueAsInteger("snake.size")) > 0)
			rect.x++;

		while ((rect.y % ConfigGetValueAsInteger("snake.size")) > 0)
			rect.y++;
	}

	SDL_FillRect(screen,&rect,0x00FFFF);
}

void StartGame(SDL_Surface *screen)
{
	SDL_Rect rect;

	srand(time(NULL));
	rect.h = ConfigGetValueAsInteger("snake.size");
	rect.w = rect.h;
	rect.y = (rand() % screen->h);
	rect.x = (rand() % screen->w);

	while ((rect.x % ConfigGetValueAsInteger("snake.size")) > 0)
		rect.x++;

	while ((rect.y % ConfigGetValueAsInteger("snake.size")) > 0)
		rect.y++;

	head_x = rect.x;
	head_y = rect.y;
	TileAdd(rect.x, rect.y, rect.w, rect.h);
	SDL_FillRect(screen,&rect,0x00FF00);

	PutApple(screen);
}

void SnakeMove(SDL_Surface *screen)
{
	int ss = ConfigGetValueAsInteger("snake.size");

	switch (dir) {
		case DIR_LEFT: head_x -= ss;
				break;
		case DIR_UP: head_y -= ss;
				break;
		case DIR_RIGHT: head_x += ss;
				break;
		case DIR_DOWN: head_y += ss;
				break;
	}

	if (((head_x < 0) || (head_x > screen->w))
		|| ((head_y < 0) || (head_y > screen->h))) {
		GameLost(screen);
		return;
	}

	// Draw tile
	SDL_Rect rect;
	rect.h = ConfigGetValueAsInteger("snake.size");
	rect.w = rect.h;
	rect.y = head_y;
	rect.x = head_x;

	if (TileCheckForCollision(rect.x, rect.y, rect.w, rect.h) == 1) {
		GameLost(screen);
		return;
	}

	TileAdd(rect.x, rect.y, rect.w, rect.h);

	SDL_FillRect(screen,&rect,0x00FF00);
	SDL_Flip(screen);
}

unsigned long GetTimeMs(void)
{
	struct timeval tv;
	gettimeofday(&tv, NULL);

	return (tv.tv_sec * 1000) + (tv.tv_usec / 1000);
}

void DrawScreen(SDL_Surface* screen)
{ 
	int rc;
	int x, y, ytimesw;
  
	if (SDL_MUSTLOCK(screen)) {
		if(SDL_LockSurface(screen) < 0)
			return;
	}

	SDL_FillRect(screen, NULL, SDL_MapRGB(screen->format, 0,0,0));

	FreeTiles();
	StartGame(screen);
	wait_input = 0;

	 if (SDL_MUSTLOCK(screen))
		SDL_UnlockSurface(screen);

	SDL_Flip(screen); 
}

int main(int argc, char* argv[])
{
	SDL_Surface *screen;
	SDL_Event event;
	int done = 0;
	int h, w, fs, flags, delay;
	long old_ticks;

	InitTiles();
	InitConfigs();

	if (ConfigLoad("Snake.cfg") != 0) {
		fprintf(stderr, "Cannot load configuration file Snake.cfg\n");
		return 1;
	}

	h = ConfigGetValueAsInteger("screen.height");
	w = ConfigGetValueAsInteger("screen.width");
	fs = ConfigGetValueAsBoolean("screen.fullscreen");
	delay = ConfigGetValueAsInteger("snake.delay");

	if (SDL_Init(SDL_INIT_VIDEO) < 0)
		return 1;

	if (TTF_Init() != 0) {
		DPRINTF("%s: Error '%s'\n", __FUNCTION__, TTF_GetError());
		return 1;
	}
   
	flags = SDL_HWSURFACE;
	if (fs == 1)
		flags |= SDL_FULLSCREEN;
	if (!(screen = SDL_SetVideoMode(w, h, DEPTH, flags))) {
		TTF_Quit();
		SDL_Quit();
		return 1;
	}

	if (loadFonts() != 0) {
		TTF_Quit();
		SDL_Quit();
		return 2;
	}

	SDL_WM_SetCaption(APP_NAME, APP_NAME);
	DrawScreen(screen);
	old_ticks = 0;
	while (!done)
	{
		if ((GetTimeMs() - old_ticks > delay) && (!wait_input)) {
			SnakeMove(screen);
			old_ticks = GetTimeMs();
		}
		while(SDL_PollEvent(&event)) {
			switch (event.type) {
				case SDL_QUIT:
					done = 1;
					break;
				case SDL_KEYDOWN:
					if (event.key.keysym.sym == SDLK_ESCAPE)
						done = 1;
					else {
						switch (wait_input) {
							case 1: DrawScreen(screen);
								break;
							default:
								break;
						}

						switch (event.key.keysym.sym) {
							case SDLK_UP: dir = DIR_UP;
								      break;
							case SDLK_DOWN: dir = DIR_DOWN;
									break;
							case SDLK_LEFT: dir = DIR_LEFT;
									break;
							case SDLK_RIGHT: dir = DIR_RIGHT;
									 break;
						}
					}
					break;
			}
		}
	}

	TTF_Quit();
	SDL_Quit();
	return 0;
}

