#define DEBUG_TILES
#include "Snake.h"

#ifdef DEBUG_TILES
#define DPRINTF(fmt, ...) \
do { fprintf(stderr, "[snake/tiles  ] " fmt , ## __VA_ARGS__); } while (0)
#else
#define DPRINTF(fmt, ...) \
do {} while(0)
#endif

void InitTiles(void)
{
	_tiles = NULL;
	_num_tiles = 0;
}

void TileAdd(int x, int y, int w, int h)
{
	if (_tiles == NULL)
		_tiles = (tTile *)malloc( sizeof(tTile) );
	else
		_tiles = (tTile *)realloc( _tiles, (_num_tiles + 1) * sizeof(tTile) );

	_tiles[_num_tiles].x = x;
	_tiles[_num_tiles].y = y;
	_tiles[_num_tiles].h = h;
	_tiles[_num_tiles].w = w;
	_num_tiles++;
}

void FreeTiles(void)
{
	free(_tiles);
	_tiles = NULL;
	_num_tiles = 0;
}

int TileCheckForCollision(int x, int y, int w, int h)
{
	int i;

	for (i = 0; i < _num_tiles; i++) {
		// 18, 5, 38, 25
		// 20, 20, 40, 40
		// 18 >= 20 || 38 <= 40
		// Tile[0] = {119, 73, 20, 20}, cur = {499, 13, 20, 20}
		// 499 >= 119 && 519 <= 139
		if (((x >= _tiles[i].x) && (x + w <= _tiles[i].x + _tiles[i].w))
			&& (y >= _tiles[i].y) && (y + h <= _tiles[i].y + _tiles[i].h)) {
			DPRINTF("%s: Tile[%d] = {%d, %d, %d, %d}, cur = {%d, %d, %d, %d}\n",
				__FUNCTION__, i, _tiles[i].x, _tiles[i].y, _tiles[i].w, _tiles[i].h,
				x, y, w, h);
			return 1;
		}
	}

	return 0;
}

int TileCheckForCollision(int x, int y, int w, int h);
void TileAdd(int x, int y, int w, int h);
void InitTiles(void);
void FreeTiles(void);
