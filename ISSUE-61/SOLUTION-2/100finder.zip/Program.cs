﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
  /* actually three basic operations.
 * +,-, connect 
 where the connect operation comes first
 we have 8 operations, so the total try count equals
 * 3^8=6151 which is okay for bruteforce
 */

            for(int i=0; i<6562;i++){
             
                List<sNumber> combination = createCombination(i,9);
                combination = removeConnects(combination);
                if(calcSum(combination,eOperation.plus)==100)
                Console.Write("+" + getCombinationString(combination) + Environment.NewLine);

                if (calcSum(combination, eOperation.minus) == 100)
                    Console.Write("-" + getCombinationString(combination) +  Environment.NewLine);

                }

            Console.ReadLine();
            
        }



        enum eOperation
        {
            plus,
            minus,
            connect,
            last
        }
        // Each number has an operation, except the last one.
       class sNumber
        {
            public eOperation op;
            public int number;
            public sNumber(eOperation par_op, int par_number)
            {
                op = par_op;
                number = par_number;
            }
        }

       

       static List<sNumber> createCombination(int parHash, int parLength)
        {
            List<sNumber> lNumbers = new List<sNumber>();

            for (int i = 1; i < parLength; i++)
            {
                int mod = (parHash/((int) Math.Pow(3, i-1)) % 3) ;
                switch(mod){
                    case 0:  lNumbers.Add(new sNumber(eOperation.plus,i));
                        break;
                    case 1: lNumbers.Add(new sNumber(eOperation.minus, i));
                        break;
                    case 2: lNumbers.Add(new sNumber(eOperation.connect, i));
                        break;
                }         
            }
            lNumbers.Add(new sNumber(eOperation.last, parLength));
            return lNumbers;
        }

        static String getCombinationString(List<sNumber> parList)
        {
            string tmpString = "";
            foreach (sNumber iNumber in parList)
            {
                tmpString += iNumber.number.ToString();

                switch (iNumber.op)
                {
                    case eOperation.plus: tmpString += "+";
                        break;
                    case eOperation.minus: tmpString += "-";
                        break;
                    default: break;
                }

            }
            return tmpString;
        }


       static List<sNumber> removeConnects(List<sNumber> parList){
           // First multiply
           List<sNumber> tmpList = new List<sNumber>();
          while(parList.Count>0){
              sNumber firstNumber =parList.First<sNumber>();             

             if( parList.First<sNumber>().op==eOperation.connect)
             {
                 parList.RemoveAt(0);
                 parList.First<sNumber>().number += firstNumber.number * 10;
             }
             else
             {            
                 tmpList.Add(firstNumber);
                 parList.RemoveAt(0);
             }          
          }
          return tmpList;
        }

       static int calcSum(List<sNumber> parList, eOperation firstOperation)
       {
           int sum = 0;
           eOperation currentOperation=firstOperation;
           foreach (sNumber iNumber in parList)
           {
               switch (currentOperation)
               {
                   case eOperation.plus: sum += iNumber.number;
                       break;
                   case eOperation.minus: sum -= iNumber.number;
                       break;
                   default: break;
               }
             
              currentOperation = iNumber.op;
           }

           return sum;

       }




    }
}
