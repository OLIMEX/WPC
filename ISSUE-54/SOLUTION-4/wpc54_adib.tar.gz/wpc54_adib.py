#!/usr/bin/env python

__author__ = 'theAdib'
__copyright__ = 'Copyright (c) 2014 Adib'
__license__ = 'New-style BSD'
__version__ = '0.1'

import scipy.io.wavfile
import numpy
import numpy.fft
import matplotlib.pyplot
from scipy.fftpack import fftfreq
from scipy.fftpack import fft

rate, wavdata = scipy.io.wavfile.read('440hz.wav')

s = numpy.abs(numpy.fft.rfft(wavdata))
f = numpy.linspace(0, rate / 2, len(s))
print s
print f

matplotlib.pyplot.plot(f, s)
matplotlib.pyplot.show()




