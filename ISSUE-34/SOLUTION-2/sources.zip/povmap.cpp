#include "povmap.h"

POVMap::POVMap()
{
    for(int angle = 0; angle < 360; angle++)
    {
        sintable[angle] = sin(angle * M_PI / 180);
        costable[angle] = cos(angle * M_PI / 180);
    }
}

void POVMap::load()
{
    load("test2.png");
}

void POVMap::load(QString filename)
{
    // Load bitmap
    pixmap.load(filename);

    // Crop and convert to black and white
    QBitmap cropped = pixmap.copy(0,0,140,140);
    QImage image = cropped.toImage();
    if (!image.isNull())
    {
        image.convertToFormat(QImage::Format_Mono);
        // Extract pixels and store them in an array
        for(int x = 0; x < image.width(); x++)
            for (int y =0 ; y < image.height(); y++)
            {
                pixels[x][y] = (char)image.pixelIndex(x,y);
            }
    }
}

void POVMap::convert()
{
    int x,y;

    for(int angle = 0; angle < 360; angle++)
    {
        double cosine = costable[angle];
        double sine = sintable[angle];

        for (int dist = 0; dist < 100; dist++)
        {
            x = 70 + (int)(dist * cosine);
            y = 70 + (int)(dist * sine);
            if ((0 <= x) && (x <= 140) && (0 <= y) && (y <= 140))
                lines[angle][dist] = pixels[x][y];
            else
                lines[angle][dist] = 0;
        }
    }
}
