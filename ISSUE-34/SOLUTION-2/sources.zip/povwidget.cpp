#include "povwidget.h"


POVWidget::POVWidget(QWidget *parent)
    : QWidget(parent)
{
    setBackgroundRole(QPalette::Light);
    setAutoFillBackground(true);
}

void POVWidget::loadFile()
{
    QFileDialog chooser;
    QString filename = chooser.getOpenFileName(this,
                                               "Select a file to open",
                                               ".",
                                               "*.bmp *.gif *.jpg *.jpeg *.png *.pbm *.pgm *.ppm *.xbm *.xpm");
    mapper.load(filename);
    mapper.convert();
    angle = 0;
    timer.start(10,this);
}

void POVWidget::setDelay(QString delay)
{
    int d = delay.toInt();
    timer.stop();
    timer.start(d, this);
}

void POVWidget::paintEvent(QPaintEvent * /* event */)
{
    QPainter painter(this);
    painter.setPen(QColor::fromRgb(0,0,0));

    int x,y;
    char* line = mapper.lines[angle];
    double cosine = mapper.costable[angle];
    double sine = mapper.sintable[angle];
    for(int dist = 0; dist < 100; dist++)
    {
        if (line[dist] == 1)
        {
            x = 70 + (int)(dist * cosine);
            y = 70 + (int)(dist * sine);
            painter.drawPoint(x,y);
        }
    }
}

void POVWidget::timerEvent(QTimerEvent *event)
{
    if (event->timerId() == timer.timerId())
    {
        if ((angle = angle + 1) >= 360) angle = 0;
        update();
    }
    else
    {
        QWidget::timerEvent(event);
    }
}
