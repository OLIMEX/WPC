#ifndef POVMAP_H
#define POVMAP_H

#include <QPixmap>
#include <QBitmap>
#include <QImage>
#include <QRgb>
#include <math.h>

class POVMap
{
    public:

        POVMap();

        // An array holding the pixels from the bitmap
        char pixels[140][140];
        // An array of 100 led states for 360 angles
        char lines[360][100];

        // Precalculated sine and cosine
        double sintable[360];
        double costable[360];

        // Used to load the bitmap from file
        QBitmap pixmap;

        // Load the bitmap
        void load();
        void load(QString filename);
        // ... and convert it to led states
        void convert();
};

#endif // POVMAP_H
