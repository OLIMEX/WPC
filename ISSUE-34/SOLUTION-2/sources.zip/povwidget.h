#ifndef POVWIDGET_H
#define POVWIDGET_H

#include <QWidget>
#include <QPainter>
#include <QTimer>
#include <QBasicTimer>
#include <QTimerEvent>
#include <QPixmap>
#include <QBitmap>
#include <QImage>
#include <QRgb>
#include <QLabel>
#include <QFileDialog>
#include <math.h>
#include "povmap.h"

class POVWidget : public QWidget
{
    Q_OBJECT

public:
    POVWidget(QWidget *parent = 0);

public slots:
     void loadFile();
     void setDelay(QString delay);

protected:
    void paintEvent(QPaintEvent *event);
    void timerEvent(QTimerEvent *event);

private:
    POVMap mapper;
    QBasicTimer timer;
    int angle;
    QPixmap buffer;
};

#endif // POVWIDGET_H
