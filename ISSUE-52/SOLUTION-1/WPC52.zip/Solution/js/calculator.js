$(document).ready(function() {

    $('#calcBtn').click(function() {
        var x = parseFloat($('#x').val());
        var y = parseFloat($('#y').val());
        var circumference = parseFloat($('#circumference').val());
        var bandWidth = parseFloat($('#bandWidth').val());

        if (circumference <= 0 || isNaN(circumference)) {
            $('#error').html("Please enter valid shaft circumference!");
        }
        else if (bandWidth <= 0 || isNaN(bandWidth)) {
            $('#error').html("Please enter valid band width!");
        }
        else if (isNaN(x)) {
            $('#error').html("Please enter valid X!");
        }
        else if (isNaN(y)) {
            $('#error').html("Please enter valid Y!");
        }
        else {
            // Validate band width and shaft diameter
            var maxXY = (bandWidth - 4 * (circumference/3.14)) / 8;
            if (x >= maxXY || y >= maxXY || maxXY <= 0) {
                $('#error').html("Band width too small!");
            }
            else {
                var angles = getAngles(x, y, circumference, bandWidth);
                $('#m1').html(angles.m1Angle);
                $('#m2').html(angles.m2Angle);
            }
        }
    });

    function getAngles(x, y, circumference, bandWidth) {
        var angles = {m1Angle: 0, m2Angle: 0};

        // Get x-axis movement angles for motor1 and motor2
        var xAngles = getXAngles(x, circumference);
        // Get y-axis movement angles for motor1 and motor2
        var yAngles = getYAngles(y, circumference);

        // Calculate total angles values
        angles.m1Angle = xAngles.m1Angle + yAngles.m1Angle;
        angles.m2Angle = xAngles.m2Angle + yAngles.m2Angle;

        return angles;
    }

    function getXAngles(x, circumference) {
        angle = 360 * (x / circumference);
        if (x = 0) {
            return {m1Angle: 0, m2Angle: 0};
        }
        else {
            return {m1Angle: -angle, m2Angle: -angle};
        }
    }

    function getYAngles(y, circumference) {
        angle = 360 * (y / circumference);
        if (y = 0) {
            return {m1Angle: 0, m2Angle: 0};
        }
        else {
            return {m1Angle: angle, m2Angle: -angle};
        }
    }
});
