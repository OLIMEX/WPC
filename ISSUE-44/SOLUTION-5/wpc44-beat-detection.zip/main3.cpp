#include "FFT.h"
#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include <iostream>
#include <stdint.h>

#define FFT_WINDOW_SIZE 128 //more steps for more precision in finding frequency

// adapted from https://github.com/dccafe/raspberry-fft/blob/master/src/main.cpp that uses fft-cpp
// https://github.com/dccafe/raspberry-fft/blob/master/LICENSE

//for making eeg file
//sudo yum install vim subversion
//svn checkout http://fft-cpp.googlecode.com/svn/trunk/ fft-cpp-read-only 
//wget https://raw.github.com/OLIMEX/WPC/master/ISSUE-44/ECGSAMPLE.txt
//xxd -r -p ECGSAMPLE.txt eegbin.dat
//hexdump -C ecgbin.dat #validate -> OK

using namespace std;

typedef struct modeeg_packet
{
  uint8_t sync0; // = 0xA5
  uint8_t sync1; // = 0x5A
  uint8_t version; // = 2
  uint8_t count; // packet counter. Increases by 1 each packet.
  uint16_t data[6]; // 10-bit sample (= 0 - 1023) in big-endian (Motorola, not Intel) format.
  uint8_t switches; // State of PD5 to PD2, in bits 3 to 0. (push buttons?)
} eeg_packet;

//tmp for reading EEG file
eeg_packet tmp[FFT_WINDOW_SIZE];

//converts from big to little-endian
uint16_t bigtolittleendian10bit(uint16_t u)
{
  return (((u & 0x00ff) << 8) | ((u & 0xff00) >> 8)) & 0x03ff;
}

//g++ main3.cpp FFT.cc -O2 -o main3
int main(int argc, char **argv)
{
  // Reading from stdin, we can use "cat" for ECG file to this program (cat eegbin.dat | ./main3)
  FILE* instream=fopen("/dev/stdin", "r");
  
  // Declaring a vector to store time samples
  vector<FFT::Complex> time_samples(FFT_WINDOW_SIZE, 0);
  
  // Declaring magnitude vector
  double * magnitude = new double[FFT_WINDOW_SIZE];
  
  // Variable max is the temporary maximum frequency amplitude
  int max_index=0;
  double max=0;
  double volume=0;
  double frequency=0;
  
  // to create instance of fft.
  FFT dft(FFT_WINDOW_SIZE);
  
  while(fread(tmp, FFT_WINDOW_SIZE, sizeof(eeg_packet), instream))
  {
    // Copy all samples to the Complex Vector
    
    for(int i=0;i<FFT_WINDOW_SIZE;i++) 
    { // read only prob no. 0 (tmp[i].data[0])
      //don't use bigtolittleendian10bit() if not need (big-endian machine)
      ///uint16_t am = bigtolittleendian10bit(tmp[i].data[0]);
      ///cout << std::hex << "amplitude=" << am << endl;
      ///time_samples[i] = am;
      ////time_samples[i] = (i%2) * 0x0ff; //test maximum frequency
      ////time_samples[i] = ((i%4)==0) ? 0x0ff : 0;
      ////time_samples[i] = (((i%2)==0) ? 0x0f : 0) + (((i%4)==0) ? 0x1f0 : 0);
      time_samples[i] = bigtolittleendian10bit(tmp[i].data[0]);
      
    }

    // Call FFT
    vector <FFT::Complex> freq_samples = dft.transform(time_samples);
    
    // Get magnitude vector
    // Is there SIMD instruction set?
    for(int i=0;i<FFT_WINDOW_SIZE;i++) 
    {
      magnitude[i] = abs(freq_samples[i]);
      //cout <<"fft" <<i<<"="<< magnitude[i] << endl;
    }
    // Find vector that has maximum magnitude, it should be fundamental frequency 
    // this loop ignoring DC value (0 Hz volume in magnitude[0]) and using only first half of magnitude[]
    // frequencies that more than (sampling rate)/2 cannot be detected http://en.wikipedia.org/wiki/Nyquist_frequency
    // "transmitted from the ModularEEG at 256Hz" - assume this is sampling rate
    for(int i=1;i<(FFT_WINDOW_SIZE/2);i++)
    {
      //cout << ">m" << i << "=" << magnitude[i] << endl; ;
      if(magnitude[i]>=max) 
      {
	volume+=magnitude[i];
        max=magnitude[i];
        max_index=i;
      }
    }
    
    // to calculate frequency 
    frequency = 256.00 * max_index / FFT_WINDOW_SIZE;
    //if (volume > 95.0)   // if volume is too small, Frequency should not acceptable
      cout << "Total volume=" << volume << " Frequency=" << frequency << endl; 
    
    // to reset variables for next loop
    max = 0;   
    max_index = 0; 
    volume = 0;
  }
  // no GC in C++, sorry
  delete[] magnitude;
  // to close file
  fclose(instream);
}
