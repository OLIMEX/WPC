#-*- coding:utf-8 -*-
import string
from random import shuffle

def is_punct(c):
    if c ==" " or c=="\r" or c=="\n" or c=="\t" or c in string.punctuation:
        return True
    else:
        return False

def scram(s):
    if len(s) <=3:
        return s

    word2 = word = s[1:-1]
    while (word == word2):
        lword = list(word)
        shuffle(lword)
        word = ''.join(lword)    

    return s[0] + word + s[-1]

#input string
s2 = """According to a researcher @ "Cambridge University",
it doesn't matter in what order the letters in a word are, the only important thing is that the 1-st and last letter be at the right place. 
The rest can be a total mess and you can still read it without problem. This is because the human mind does not read every letter by itself but the word as a whole. 
Unfortunately, Thai language doesn't (conventionally) put spaces between words or has full stop
for example: makeingscript"""

s2 += u"นมเปรี้ยวบัลแกเรีย"

#output string
s3 = ""
#buffer string
sc = ""

separatedwords = ["makeing", "script", u"บัลแกเรีย", u"นมเปรี้ยว"]

for c in s2:
    if is_punct(c):
        s3 += scram(sc)
        s3 += c 
        sc = ""
    
    elif sc in separatedwords:
        s3 += scram(sc)
        s3 += " " 
        sc = c
        
    else:
        sc += c

if sc != "":
    s3 += scram(sc)
    
print s3