using System;
using Gtk;
using System.Drawing;

public partial class MainWindow: Gtk.Window
{	
	private Bitmap blob;
	private Point center;

	public MainWindow (): base (Gtk.WindowType.Toplevel)
	{
		Build ();

		// Load bitmap and calculate/show center of gravity
		blob = (Bitmap)Bitmap.FromFile ("100x100.png");
		if (blob != null)
		{
			center = gravity_gtk.Calculator.GetCenter (blob);
			label.Text = String.Format ("({0},{1})", center.X, center.Y);
		}
	}
	
	protected void OnDeleteEvent(object sender, DeleteEventArgs a)
	{
		Application.Quit();
		a.RetVal = true;
	}

	protected void Exit(object sender, EventArgs e)
	{
		Application.Quit();
	}	

	// Handle ExposeEvent
	protected void Paint (object o, ExposeEventArgs args)
	{
		if (blob != null) 
		{
			int scale = 2;

			// Draw the bitmap
			Graphics g = Gtk.DotNet.Graphics.FromDrawable (drawingarea.GdkWindow); 
			g.DrawImage (blob, 0, 0, blob.Width * scale, blob.Height * scale);

			// Draw red crosshairs
			Pen p = new Pen (Color.Red);
			g.DrawLine (p, new Point (20, center.Y * scale), new Point (180, center.Y * scale));
			g.DrawLine (p, new Point (center.X * scale, 20), new Point (center.X * scale, 180));
		}
	}

}
