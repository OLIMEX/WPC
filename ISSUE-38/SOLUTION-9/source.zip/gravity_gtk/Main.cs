/*
 * Olimex WPC #38 - Calculate center of gravity
 *
 *
 * Environment:
 *    Mono 2.10.8.1 (Debian 2.10.8.1-5ubuntu1)
 *    GTK 2.24.17
 *    GTK# 2.12.0.0
 *
*/
using System;
using Gtk;

namespace gravity_gtk
{
	class MainClass
	{
		public static void Main (string[] args)
		{
			Application.Init ();
			MainWindow win = new MainWindow ();
			win.Show ();
			Application.Run ();
		}
	}
}
