using System;
using System.Drawing;
using Gtk;

namespace gravity_gtk
{
	public class Calculator
	{
		public static Point GetCenter(Bitmap blob)
		{
			int count = 0; 
			double xsum = 0;
			double ysum = 0;

			for (int x = 0; x < blob.Width; x++)
				for (int y = 0; y < blob.Height; y++)
				{
					if (blob.GetPixel(x,y).GetBrightness() == 0)
					{
						xsum += x;
						ysum += y;
						count++;
					}
				}

			int xavg = (int)Math.Round(xsum / count);
			int yavg = (int)Math.Round(ysum / count);

			return new Point(xavg, yavg);
		}
	}
}

