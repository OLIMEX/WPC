#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdarg.h>

#define PNG_DEBUG 3
#include <png.h>

void abort_(const char * s, ...)
{
	va_list args;
	va_start(args, s);
	vfprintf(stderr, s, args);
	fprintf(stderr, "\n");
	va_end(args);
	abort();
}

int x, y;

int width, height;
png_byte color_type;
png_byte bit_depth;

png_structp png_ptr;
png_infop info_ptr;
int number_of_passes;
png_bytep * row_pointers;

unsigned char getBit( unsigned char p, int bit )
{
	return ((p>>(7-bit))&0x1)?0xff:0x0;
}

void center_of_gravity(png_bytep *p, int width, int height)
{
	int x,y;
	unsigned int sumx = 0, sumy = 0, count = 0;
	for(y=0;y<height;y++)
	{
		png_byte* pxl = p[y] ;
		int pb = 0 ;
		for(x=0;x<width;++x)
		{			
			unsigned char bpxl = getBit(*pxl,pb);
			if ( !bpxl ) { sumx += x ; sumy += y; count++; }
			if ( pb++ == 7 ) { pxl++ ; pb = 0; }
		}
	}
	printf("cog=%f,%f\n", sumx/(float)count, sumy/(float)count );
}

void read_png_file(char* file_name)
{
	char header[8];    // 8 is the maximum size that can be checked

	/* open file and test for it being a png */
	FILE *fp = fopen(file_name, "rb");
	if (!fp)
		abort_("[read_png_file] File %s could not be opened for reading", file_name);
	fread(header, 1, 8, fp);
	if (png_sig_cmp(header, 0, 8))
		abort_("[read_png_file] File %s is not recognized as a PNG file", file_name);


	/* initialize stuff */
	png_ptr = png_create_read_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);

	if (!png_ptr)
		abort_("[read_png_file] png_create_read_struct failed");

	info_ptr = png_create_info_struct(png_ptr);
	if (!info_ptr)
		abort_("[read_png_file] png_create_info_struct failed");

	if (setjmp(png_jmpbuf(png_ptr)))
		abort_("[read_png_file] Error during init_io");

	png_init_io(png_ptr, fp);
	png_set_sig_bytes(png_ptr, 8);

	png_read_info(png_ptr, info_ptr);

	width = png_get_image_width(png_ptr, info_ptr);
	height = png_get_image_height(png_ptr, info_ptr);
	color_type = png_get_color_type(png_ptr, info_ptr);
	bit_depth = png_get_bit_depth(png_ptr, info_ptr);
	
	printf("Image %dx%d, color=%d, bit_depth=%d\n", width, height, color_type, bit_depth ); 

	number_of_passes = png_set_interlace_handling(png_ptr);
	png_read_update_info(png_ptr, info_ptr);


	/* read file */
	if (setjmp(png_jmpbuf(png_ptr)))
		abort_("[read_png_file] Error during read_image");

	row_pointers = (png_bytep*) malloc(sizeof(png_bytep) * height);
	printf("line size %d\n",(int)png_get_rowbytes(png_ptr,info_ptr));
	for (y=0; y<height; y++)
		row_pointers[y] = (png_byte*) malloc(png_get_rowbytes(png_ptr,info_ptr));

	png_read_image(png_ptr, row_pointers);

	center_of_gravity( row_pointers, width, height );

	fclose(fp);
}

int main(int argc, char** argv)
{
	read_png_file(argv[1]);
}
