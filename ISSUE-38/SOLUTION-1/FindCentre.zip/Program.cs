﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace ConsoleApplication5
    {
    class Program
        {
        static void Main(string[] args)
            {
            Console.WriteLine("Loading File...");
            Bitmap image;
            if (args.Length != 0) { 
           image = new Bitmap(args[0]);
            }
            else
                {
              image = new Bitmap("100x100.png");
                }

            int size_x = image.Size.Width;
            int size_y =image.Size.Height;

            long i_x=0;
            long i_y= 0;
            // Keep track of the number of used fields
            long i = 0;

            for (int y = 0; y < size_y ; y++)
                {
                for (int x = 0; x < size_x ; x++)
                    {
                    double bright = image.GetPixel(x, y).GetBrightness();
                    if (!(bright != 0))
                        {
                        i_x+=x;
                        i_y+=y;
                        i++;
                        }
                    }
                }

               double centre_x =  (double)i_x / i;
               double centre_y =  (double)i_y / i;

               Console.WriteLine("x-{0}", centre_x);
               Console.WriteLine("y-{0}", centre_y);
               Console.Read();

                
            }
        }
    }