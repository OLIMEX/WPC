/** Automatically generated file. DO NOT MODIFY */
package com.anavi.olinuxinoromannumbers;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}