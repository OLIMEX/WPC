## Infinite Output - Weekend Programming Challenge #33

A Common Lisp solution by Dimitrios - Georgios Kontopoulos.

Some ways to run this script:

     # Using SBCL.
     sbcl --script infinite-output.lisp

     # Using GNU CLISP.
     clisp infinite-output.lisp
