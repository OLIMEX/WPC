#! /usr/bin/env python
from Tkinter import * 
from PIL import Image
from tkFileDialog import askopenfilename

center_text = 'Center at:'
center_x = -1
center_y = -1


def getCenter():
    filename=askopenfilename()
    if filename:
        image = Image.open(filename)
        image = image.convert('RGB')
        bgcolor = image.getpixel((0,  0))
        center_x = -1
        center_y = -1
        for x in range(0,  100):
            for y in range(0,  100):
              pix = image.getpixel((x,  y))
              if (pix != bgcolor):
                center_x = x
                break
            if (center_x != -1):
                break
        for y in range(0,  100):
            for x in range(0,  100):
              pix = image.getpixel((x,  y))
              if (pix != bgcolor):
                center_y = y
                break
            if (center_y != -1):
                break
        print 'Center at: (%d, %d)' % (center_x+25,  center_y+25)
        l.config(text = 'Center at: (%d, %d)' % ((center_x+25),  (center_y+25)))
        canv.image = PhotoImage(file=filename)
        canv.delete('all')
        canv.create_image(100,   100,  image=canv.image)
        canv.pack()
        
mainWindow = Frame()
canv = Canvas()
canv.config(width=200,  height=200)
canv_image = PhotoImage(file='image.gif')

canv.create_image(100,   100,  image=canv_image)
canv.pack()

l = Label(text=center_text)
l.pack()

b = Button(text='Choose image',  command=getCenter)
b.pack()



mainWindow.mainloop()


