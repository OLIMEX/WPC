
// CircleFindDlg.h : header file
//

#pragma once
#include "afxwin.h"


// CCircleFindDlg dialog
class CCircleFindDlg : public CDialog
{
// Construction
public:
	CCircleFindDlg(CWnd* pParent = NULL);	// standard constructor
	
	BOOL FindIntersectionsX( CWnd &wnd, int y, int &x0, int &x1);
	BOOL FindIntersectionsY( CWnd &wnd, int x0, int &y0, int &y1);

// Dialog Data
	enum { IDD = IDD_CIRCLEFIND_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedOk();
	CStatic m_image;
	afx_msg void OnBnClickedLoadbitmap();
};
