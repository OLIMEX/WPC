
// CircleFindDlg.cpp : implementation file
//

#include "stdafx.h"
#include "CircleFind.h"
#include "CircleFindDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

#define	SQUARE_COLOR_DISTANCE_MIN	13		

/*--------------------------------------------------------------------------------------------
in order to find the center of a circle (cllaed xCenter,yCenter) the program implement 
the following algorithm:

1) it finds two intersection between a horizzontal straight line and the circle;
we have a 50 pixel diameter circle and a 100 pixel square, so two trials 
(the first with the line at y=33 and the second with the line y=66) are enough to guarantee 
two good intersections that we call x0,x1

2) the mid point of the two intersections found have the same abscissa of circle center point,
so xCenter = (x1-x0)/2

3) we can find the vertical diameter of the circle by finding the intersection with the vertical 
straight line passing through x=xCenter (we call the two intersections y0 and y1),  in the 
same way the ordinate of the center of the circle is:
yCenter = (y1-y0)/2;
---------------------------------------------------------------------------------------------*/


// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CCircleFindDlg dialog




CCircleFindDlg::CCircleFindDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCircleFindDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CCircleFindDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_IMAGE, m_image);
}

BEGIN_MESSAGE_MAP(CCircleFindDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDOK, &CCircleFindDlg::OnBnClickedOk)
	ON_BN_CLICKED(IDC_LOADBITMAP, &CCircleFindDlg::OnBnClickedLoadbitmap)
END_MESSAGE_MAP()


// CCircleFindDlg message handlers

BOOL CCircleFindDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CCircleFindDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CCircleFindDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CCircleFindDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

int SquareColorDistance(COLORREF clr1, COLORREF clr2)
{
	int r1 = GetRValue(clr1);
	int g1 = GetRValue(clr1);
	int b1 = GetBValue(clr1);
	
	int r2 = GetRValue(clr2);
	int g2 = GetRValue(clr2);
	int b2 = GetBValue(clr2);

	return(  (r2-r1)*(r2-r1) + (g2-g1)*(g2-g1) + (b2-b1)*(b2-b1) );
	
}

//find the intersecion between the circle and an horizzontal straight line which equation is: y=y0
BOOL CCircleFindDlg::FindIntersectionsX( CWnd &wnd, int y0, int &x0, int &x1)
{
	CDC *pDc=this->m_image.GetDC();
	
	RECT rect;
	wnd.GetClientRect(&rect);
	
	COLORREF bgColor = pDc->GetPixel(0,0);	//the 0,0 point always belong to background
	
	BOOL found=0;	
	//find first intersection
	for(int x=rect.left; x<rect.right; x++){
		COLORREF clr = pDc->GetPixel(x,y0);
		if(SquareColorDistance(clr,bgColor) > SQUARE_COLOR_DISTANCE_MIN ){		
			//found first intersections
			x0=x;				//save the x coordinate	
			found++;
			break;
		}
	}

	//find second intersection
	if(found){
		for(int x=x0+1; x<rect.right; x++){
			COLORREF clr = pDc->GetPixel(x,y0);
			if(SquareColorDistance(clr,bgColor) <= SQUARE_COLOR_DISTANCE_MIN ){		
				//found second intersections
				x1 = x-1;			//save the x coordinate	of previous iteration
				found++;
				break;
			}
		}
	}

	if(found !=2 ){
		return FALSE;	//no intersections found		
	}
	
	if( found==2 && (x1-x0) < 22){
		//the straight line is nearly tangent to circle; 
		//the truncation error is too high
		//invalidate the result and let the program to find a more suitable intersection
		return FALSE;
	}

	
	return TRUE;	//found 2 valid intersections !
}

//find the intersecion between the circle and a vertical straight line which equation is: x=x0
BOOL CCircleFindDlg::FindIntersectionsY( CWnd &wnd, int x0, int &y0, int &y1)
{
	CDC *pDc=this->m_image.GetDC();
	
	RECT rect;
	wnd.GetClientRect(&rect);
	
	COLORREF bgColor = pDc->GetPixel(0,0);	//the 0,0 point always belong to background
	
	BOOL found=0;	
	//find first intersection
	for(int y=rect.top; y<rect.bottom; y++){
		COLORREF clr = pDc->GetPixel(x0,y);
		if(SquareColorDistance(clr,bgColor) > SQUARE_COLOR_DISTANCE_MIN ){		
			//found first intersections
			y0=y;				//save the x coordinate	
			found++;
			break;
		}
	}

	//find second intersection
	if(found){
		for(int y=y0+1; y<rect.bottom; y++){
			COLORREF clr = pDc->GetPixel(x0,y);
			if(SquareColorDistance(clr,bgColor) <= SQUARE_COLOR_DISTANCE_MIN ){		
				//found second intersections
				y1 = y-1;			//save the x coordinate	of previous iteration
				found++;
				break;
			}
		}
	}

	if(found !=2 ){
		return FALSE;	//no intersections found		
	}
	
	if( found==2 && (y1-y0) < 22){
		//the straight line is nearly tangent to circle; 
		//the truncation error is too high
		//invalidate the result and let the program to find a more suitable intersection
		return FALSE;
	}

	
	return TRUE;	//found 2 valid intersections !
}


void CCircleFindDlg::OnBnClickedOk()
{
	int x0,x1;

	RECT rect;
	m_image.GetClientRect(&rect);

	int y = (rect.bottom-rect.top) /3;
	if( ! FindIntersectionsX( m_image,y, x0, x1)){
		y = (rect.bottom-rect.top) *2 /3;
		if(! FindIntersectionsX( m_image,y, x0, x1)){
			MessageBox("Invalid bitmap, Circle not found","ERROR",MB_OK);
			return;
		}
	}
	//now we are sure that x0 and x1 are valid
	//the xCenter of the circle is the mid point between x0 and x1 (that is the average of x0 and x1)

	int xCenter = (x0+x1)/2;
	int y0,y1;
	//now we can find the intersection with the circle and the vertical straight line passing for in x=xCenter;
	if(! FindIntersectionsY( m_image,xCenter, y0, y1)){
		MessageBox("Invalid bitmap, Circle not found","ERROR",MB_OK);
		return;
	}
	//the yCenter of the circle is the mid point between y0 and y1
	int yCenter = (y0+y1)/2;
	CString msg;
	msg.Format("The center point of the cirle is x=%d,y=%d",xCenter,yCenter);
	MessageBox(msg,"Result",MB_OK);
}

void CCircleFindDlg::OnBnClickedLoadbitmap()
{
	CImage image;

	char szFilters[]= "images (*.bmp)";
	CFileDialog dlg(
        TRUE,                                   // true for File Open dialog box
        "bmp",               // The default file name extension
        "*.bmp",                    // The default file name
        OFN_FILEMUSTEXIST ,    // bunch of flags http://msdn.microsoft.com/en-us/library/wh5hz49d.aspx
		szFilters
        );

    int result = dlg.DoModal();
    if(result != IDOK) return; // failed
    CString bitmap = dlg.GetPathName();
	image.Load(bitmap);
	m_image.SetBitmap(HBITMAP(image));
	m_image.Invalidate();
}
