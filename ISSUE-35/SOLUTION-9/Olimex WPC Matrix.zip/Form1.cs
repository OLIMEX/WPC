﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace $safeprojectname$
    {
    public partial class Form1 : Form
        {
        public Form1()
            {
            InitializeComponent();
            }



        public class cell
            {
            
            public bool free = true;
            public int step = 0;
            public int posX, posY;

            public int freeUp, freeDown, freeLeft, freeRight;

            public cell(int parX, int parY)
                {

                posX = parX;
                posY = parY;
                }
            public override string ToString()
                {
                if (step >= 0)
                    { 
                return step.ToString("000");
                    }
                else
                    {
                    return
                        "XXX";

                    }
                }
            public void reset()
                {
                free = true;
                step = 0;
                }

            public bool hasOptions()
                {
                return ((freeUp + freeDown + freeLeft + freeRight)>0);
                }


            }


        public class matrix
            {
            public cell[,] cells;
            public int steps = 0;

            public matrix(int parX, int parY)
                {
                cells = new cell[parX, parY];
                for (int x = 0; x < parX; x++)
                    {
                    for (int y = 0; y < parY; y++)
                        {
                        cells[x, y] = new cell(x,y);
                        }
                    }
                }

            public bool isSolution()
                {
                /* Solution is only reached when all fields have been touched */

                foreach (cell iCell in cells)
                    {
                    if (iCell.free == true) return false;
                    }

                return true;
                }

            public bool getCellStateFree(int parX, int parY)
                {
                if ((parX >= 0) & (parX < cells.GetLength(0)))
                    {

                    if ((parY >= 0) & (parY < cells.GetLength(1)))
                        {

                        return cells[parX, parY].free;
                        }
                    }
                return false;
                }

            public void setCellStateUsed(int parX, int parY)
                {
                if ((parX >= 0) & (parX < cells.GetLength(0)))
                    {

                    if ((parY >= 0) & (parY < cells.GetLength(1)))
                        {

                        cells[parX, parY].free = false;
                        cells[parX, parY].step = -1;
                        }
                    }

                }

            public int getFreeAdjacents(int parX, int parY)
                {
                int tempCount = 0;
                if (getCellStateFree(parX, parY)) 
                    { 
                if (getCellStateFree(parX - 1, parY) == true) tempCount++;
                if (getCellStateFree(parX + 1, parY) == true) tempCount++;
                if (getCellStateFree(parX, parY - 1) == true) tempCount++;
                if (getCellStateFree(parX, parY + 1) == true) tempCount++;

                if (tempCount == 0) tempCount++;
                }
                return tempCount;
                }

            public void enterCell(int posX, int posY)
                {
                cells[posX, posY].free = false;
                cells[posX, posY].step = ++steps;
                // Mark the possible options at the time the cell has been entered
                cells[posX, posY].freeUp = getFreeAdjacents(posX, posY - 1);
                cells[posX, posY].freeDown = getFreeAdjacents(posX, posY + 1);
                cells[posX, posY].freeLeft = getFreeAdjacents(posX - 1, posY);
                cells[posX, posY].freeRight = getFreeAdjacents(posX + 1, posY);


                }

            public String getTable()
                {
                String tmpString = "";
                for (int y = 0; y < cells.GetLength(1); y++)
                    {
                    for (int x = 0; x < cells.GetLength(0); x++)
                        {

                        tmpString += cells[x, y].ToString()+"|";
                        }
                    tmpString += Environment.NewLine;
                    }
                return tmpString;
                }



  




            }





        int posX = 0;
        int posY = 0;
     
        List<cell> history = new List<cell>();



        private void Form1_Load(object sender, EventArgs e)
            {
          

            }

   

      

       




        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
            {

            }
        matrix mmatrix = new matrix(10, 11);
        bool foundSolution = false;
        private void button1_Click(object sender, EventArgs e)
            {
            // Null determined arrays will be used.

            // Olimex Image Test Case 
           //mmatrix.setCellStateUsed(1, 2);
           //mmatrix.setCellStateUsed(2, 7);
           //mmatrix.setCellStateUsed(4, 4);
           //mmatrix.setCellStateUsed(4, 9);
           //mmatrix.setCellStateUsed(7, 1);
           //mmatrix.setCellStateUsed(7, 7);

            /* Simple even shaped matrix for testing */
           mmatrix.setCellStateUsed(0, 9);
           mmatrix.setCellStateUsed(0, 10); 
            /* Logic Assumptions
             * 
             * Cell has free neighbors. Count must be 2 for in/out ergo
             * Free Count 1 - this cell has only one other exit. it must be entered
             * Free Count 2 - 
             * If it only has 2 entries, you MUST go this way or it can not be entered again*/

            /* Alternative Management
             * 
             * a)When a cell is newly entered possible paths are saved. 
             * b)The Iteration will continue to the first available cell. It goes this way and burns that option.
             * c)If solution fails, the iterator will revert to the last cell with a free option and go there.
             */

            /* Initialize the first step */
            history.Add(mmatrix.cells[0, 0]);
            mmatrix.enterCell(0, 0);

            timer1.Start();

              
         
            }

        public void step()
            {
            /* If there is a path with only one adjacent it must be used! If that is so, all the other paths are burnt as well.*/
            if ((mmatrix.cells[posX, posY].freeRight == 1) || (mmatrix.cells[posX, posY].freeLeft == 1) || (mmatrix.cells[posX, posY].freeDown == 1) || (mmatrix.cells[posX, posY].freeUp == 1))
                {
                int tmpX = posX; int tmpY = posY;

                if (mmatrix.cells[posX, posY].freeUp == 1) { --posY; }
                else if (mmatrix.cells[posX, posY].freeDown == 1) { ++posY; }
                else if (mmatrix.cells[posX, posY].freeLeft == 1) { --posX; }
                else if (mmatrix.cells[posX, posY].freeRight == 1) { ++posX; }

                // Burn all the paths from this last cell
                mmatrix.cells[tmpX, tmpY].freeUp = 0;
                mmatrix.cells[tmpX, tmpY].freeDown = 0;
                mmatrix.cells[tmpX, tmpY].freeLeft = 0;
                mmatrix.cells[tmpX, tmpY].freeRight = 0;

                }
            else
                {//Several paths which can be chosen from.
               if (mmatrix.cells[posX, posY].freeDown > 1) { mmatrix.cells[posX, posY].freeDown = 0; ++posY; }
               else if (mmatrix.cells[posX, posY].freeRight > 1) { mmatrix.cells[posX, posY].freeRight = 0; ++posX; }                         
                else if (mmatrix.cells[posX, posY].freeLeft > 1) { mmatrix.cells[posX, posY].freeLeft = 0; --posX; }
                   if (mmatrix.cells[posX, posY].freeUp > 1) { mmatrix.cells[posX, posY].freeUp = 0; --posY; }
                }

            mmatrix.enterCell(posX, posY);
            history.Add(mmatrix.cells[posX, posY]);

            if (!mmatrix.cells[posX, posY].hasOptions())
                //There are no ways to go. We are stuck. Check if this is an solution?

                if (mmatrix.isSolution()) {

                

                    if ((posX == 1) && (posY == 0))
                        {
                        foundSolution = true;
                        textBox2.Text = mmatrix.getTable();
                        timer1.Stop();
                        }
                    }
               
                    /* Go back in the queue until we find a cell with another option to go */
                    while (!history.Last().hasOptions())
                        {
                        history.Last().reset();
                        mmatrix.steps--;
                        history.RemoveAt(history.Count - 1);

                        }
                    posX = history.Last().posX;
                    posY = history.Last().posY;


                    



            }

        private void matrixBindingSource_CurrentChanged(object sender, EventArgs e)
            {

            }
         int millionSteps=0;
        private void timer1_Tick(object sender, EventArgs e)
            {
            for (int i = 0; i < 1000000; i++)
                {
                if(!foundSolution)step();
                }
                
            millionSteps++;
            label1.Text = millionSteps.ToString()+"Million Steps";

            textBox1.Text = mmatrix.getTable();
            }

        }
    }
