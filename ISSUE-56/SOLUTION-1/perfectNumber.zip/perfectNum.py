#! /usr/bin/env python3
#===================================================================================
# Python3 Multi-process Perfect Number Calculation                        06/06/2014
#
# by MadDemus <mh@dtmh.de>                                                 
#===================================================================================
# Using Euclid expression for even perfect numbers:
# perfNum = 2^(p-1) * (2^p - 1), in case that (2^p - 1) is prime
#
# See http://en.wikipedia.org/wiki/Perfect_number#Even_perfect_numbers for details.
#
#===================================================================================

from multiprocessing import Process, Manager
import sys
import os

# Number of parallel processes used for calculation
procCount = 16

# First and maxmimum Mersenne prime exponent p, 
# used to limit calculation range.
startExponent = 2
maxExponent   = 1280

_known_primes = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97]
	
# ==============================================================================
# Miller-Rabin primality check
# Borrowed from http://jeremykun.com/2013/06/16/miller-rabin-primality-test/
# ==============================================================================
def _try_composite(a, d, n, s):
    if pow(a, d, n) == 1:
        return False
    for i in range(s):
        if pow(a, 2**i * d, n) == n-1:
            return False
    return True # n  is definitely composite
 
def isPrime(n, _precision_for_huge_n=16):
    if n in _known_primes or n in (0, 1):
        return True
    if any((n % p) == 0 for p in _known_primes):
        return False
    d, s = n - 1, 0
    while not d % 2:
        d, s = d >> 1, s + 1
    # Returns exact according to http://primes.utm.edu/prove/prove2_3.html
    if n < 1373653: 
        return not any(_try_composite(a, d, n, s) for a in (2, 3))
    if n < 25326001: 
        return not any(_try_composite(a, d, n, s) for a in (2, 3, 5))
    if n < 118670087467: 
        if n == 3215031751: 
            return False
        return not any(_try_composite(a, d, n, s) for a in (2, 3, 5, 7))
    if n < 2152302898747: 
        return not any(_try_composite(a, d, n, s) for a in (2, 3, 5, 7, 11))
    if n < 3474749660383: 
        return not any(_try_composite(a, d, n, s) for a in (2, 3, 5, 7, 11, 13))
    if n < 341550071728321: 
        return not any(_try_composite(a, d, n, s) for a in (2, 3, 5, 7, 11, 13, 17))
    # otherwise
    return not any(_try_composite(a, d, n, s) 
	   for a in _known_primes[:_precision_for_huge_n])
# ==============================================================================

def PerfNumCheck(id, n, stepSize, returnDict):
	if n < 2 or stepSize <= 0:
		print ("Process #%d: Parameter error." % id)
		sys.stdout.flush()
		return;

	max = 0	
	while n <= maxExponent:
		tmp = pow(2, n) - 1
		if isPrime(tmp):
			num = pow(2, n-1)*tmp
			if num > max:
				max = num
			print ("Process #%d: %d is perfect." % (id, num))
			sys.stdout.flush()
		n += stepSize
		
	returnDict[id] = max
	return
	
if __name__ == '__main__':

	print ("============================================================")
	print ("Multi-process Perfect number calculation          06/06/2014")
	print ()
	print ("by MadDemus <mh@dtmh.de>")
	print ("============================================================")
	print ("Using processes: %d" % procCount)
	print ("Maxmimun Mersenne prime exponent p: %d" % maxExponent)
	print ("============================================================")
	print ()
	
	manager = Manager()
	returnDict = manager.dict()
	procs = [] 

	for i in range(1, procCount+1):
		procs.append(Process(target=PerfNumCheck, args=(i, startExponent+(i-1), procCount, returnDict)))

	for p in procs:
		p.start()
	
	try:
		for p in procs:
			p.join()
	except (KeyboardInterrupt, SystemExit):
		pass
	
	print ()
	print ("==============================================")
	print ("Maximum perfect number found is: %d" % max(returnDict.values()))
	print ()
	print ("Not enough? Try increasing 'maxExponent' to do further checks...")
	print ()

	sys.exit()
